/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package trabalho5.database;

/**
 *
 * @author Rodrigo
 */
public interface Config {
    
    public String driver = "oracle.jdbc.driver.OracleDriver";
    public String url = "jdbc:oracle:thin:@grad.icmc.usp.br:15215:orcl";
    public String username = "a7972630";
    public String password = "a7972630";
    
}
